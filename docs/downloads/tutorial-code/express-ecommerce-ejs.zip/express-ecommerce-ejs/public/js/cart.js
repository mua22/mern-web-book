// Identical cart logic to the static site's js/cart.js -- the cart still
// lives in localStorage either way, since it's per-browser state the
// server never needs to know about. The only thing that changed is WHERE
// the global PRODUCTS array it reads from comes from (see views/cart.ejs).
function getCart() {
  return JSON.parse(localStorage.getItem("cart") || "[]");
}

function saveCart(cart) {
  localStorage.setItem("cart", JSON.stringify(cart));
  updateCartCount();
}

function addToCart(productId) {
  const cart = getCart();
  const existing = cart.find((item) => item.id === productId);
  if (existing) {
    existing.qty += 1;
  } else {
    cart.push({ id: productId, qty: 1 });
  }
  saveCart(cart);
  alert("Added to cart!");
}

function removeFromCart(productId) {
  saveCart(getCart().filter((item) => item.id !== productId));
  renderCartPage();
}

function updateCartCount() {
  const el = document.getElementById("cart-count");
  if (el) el.textContent = getCart().reduce((sum, item) => sum + item.qty, 0);
}

function renderCartPage() {
  const container = document.getElementById("cart-items");
  if (!container) return;

  const cart = getCart();
  if (cart.length === 0) {
    container.innerHTML = '<p class="empty-state">Your cart is empty.</p>';
    document.getElementById("cart-total").textContent = "$0.00";
    return;
  }

  let total = 0;
  container.innerHTML = cart
    .map((item) => {
      const product = PRODUCTS.find((p) => p.id === item.id);
      if (!product) return "";
      const lineTotal = product.price * item.qty;
      total += lineTotal;
      return `
        <div class="cart-item">
          <span class="cart-item-icon">${product.icon}</span>
          <span class="cart-item-name">${product.name}</span>
          <span class="cart-item-qty">x${item.qty}</span>
          <span class="cart-item-price">$${lineTotal.toFixed(2)}</span>
          <button class="remove-btn" onclick="removeFromCart(${product.id})">Remove</button>
        </div>
      `;
    })
    .join("");
  document.getElementById("cart-total").textContent = `$${total.toFixed(2)}`;
}

function checkout() {
  if (getCart().length === 0) {
    alert("Your cart is empty.");
    return;
  }
  alert("Thanks for your order!");
  saveCart([]);
  renderCartPage();
}

document.addEventListener("DOMContentLoaded", updateCartCount);

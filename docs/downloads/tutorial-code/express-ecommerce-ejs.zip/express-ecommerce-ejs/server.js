const express = require("express");
const expressLayouts = require("express-ejs-layouts");
const products = require("./data/products");

const app = express();
app.set("view engine", "ejs");
app.set("views", "./views");
app.use(expressLayouts);
app.set("layout", "layout"); // views/layout.ejs wraps every page
app.use(express.static("public")); // serves /css/style.css and /js/cart.js

app.get("/", (req, res) => {
  res.render("index", { title: "Shoply - Home", products });
});

app.get("/products/:id", (req, res) => {
  const product = products.find((p) => p.id === Number(req.params.id));
  if (!product) {
    return res.status(404).render("not-found", { title: "Not Found" });
  }
  res.render("product", { title: `Shoply - ${product.name}`, product });
});

app.get("/cart", (req, res) => {
  // The cart page itself is still rendered by the server (so it gets the
  // shared layout for free) -- but the ITEMS in it come from the browser's
  // localStorage, so public/js/cart.js fills them in after the page loads.
  res.render("cart", { title: "Shoply - Cart", products });
});

const PORT = 3003;
app.listen(PORT, () => {
  console.log(`Shoply (Express + EJS) listening on http://localhost:${PORT}`);
});

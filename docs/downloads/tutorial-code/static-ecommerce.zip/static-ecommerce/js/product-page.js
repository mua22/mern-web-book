// product.html has no server to ask "which product is this?" -- so it reads
// the id out of its OWN url (?id=2) and looks it up in the same PRODUCTS
// array index.html uses, entirely in the browser, after the page has loaded.
function renderProductPage() {
  const params = new URLSearchParams(window.location.search);
  const id = Number(params.get("id"));
  const product = PRODUCTS.find((p) => p.id === id);
  const container = document.getElementById("product-detail");

  if (!product) {
    container.innerHTML = "<p>Product not found.</p>";
    return;
  }

  container.innerHTML = `
    <div class="product-detail-icon">${product.icon}</div>
    <div class="product-detail-info">
      <h1>${product.name}</h1>
      <p class="price">$${product.price.toFixed(2)}</p>
      <p class="description">${product.description}</p>
      <button class="add-to-cart-btn" onclick="addToCart(${product.id})">Add to Cart</button>
    </div>
  `;
}

document.addEventListener("DOMContentLoaded", renderProductPage);

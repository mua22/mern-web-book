// The product catalog. On a real site this would come from a database --
// here it's just a plain JS array that both index.html and product.html read.
const PRODUCTS = [
  { id: 1, name: "Classic Leather Backpack", price: 59.99, icon: "🎒", description: "A roomy, durable backpack with a padded laptop sleeve and full-grain leather straps." },
  { id: 2, name: "Wireless Headphones", price: 89.99, icon: "🎧", description: "Over-ear headphones with active noise cancellation and 30 hours of battery life." },
  { id: 3, name: "Ceramic Coffee Mug", price: 14.99, icon: "☕", description: "A 12oz hand-glazed ceramic mug that keeps your coffee warm for longer." },
  { id: 4, name: "Canvas Sneakers", price: 44.99, icon: "👟", description: "Lightweight everyday sneakers with a rubber sole and breathable canvas upper." },
];

const express = require("express");
const expressLayouts = require("express-ejs-layouts");

const app = express();
app.set("view engine", "ejs");
app.set("views", "./views");
app.use(expressLayouts);
app.set("layout", "layout"); // views/layout.ejs is the shared shell for every page
app.use(express.static("public")); // serves /style.css and any other static file
app.use(express.urlencoded({ extended: true })); // parses an HTML <form> POST body into req.body

let tasks = [
  { id: 1, title: "Learn EJS", done: false },
  { id: 2, title: "Add a shared layout", done: false },
];
let nextId = 3;

app.get("/", (req, res) => {
  res.render("index", { title: "My Tasks", tasks });
});

app.post("/tasks", (req, res) => {
  const title = (req.body.title || "").trim();
  if (title) {
    tasks.push({ id: nextId++, title, done: false });
  }
  res.redirect("/"); // Post/Redirect/Get -- see Part 5
});

app.post("/tasks/:id/toggle", (req, res) => {
  const task = tasks.find((t) => t.id === Number(req.params.id));
  if (task) task.done = !task.done;
  res.redirect("/");
});

app.post("/tasks/:id/delete", (req, res) => {
  tasks = tasks.filter((t) => t.id !== Number(req.params.id));
  res.redirect("/");
});

const PORT = 3002;
app.listen(PORT, () => {
  console.log(`EJS Tasks app listening on http://localhost:${PORT}`);
});

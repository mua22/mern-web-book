const express = require("express");

const app = express();
app.use(express.json()); // parses a JSON request body into req.body -- no manual chunk-reading needed

let tasks = [
  { id: 1, title: "Learn Express", done: false },
  { id: 2, title: "Rewrite the http-module API", done: false },
];
let nextId = 3;

app.get("/tasks", (req, res) => {
  res.json(tasks);
});

app.get("/tasks/:id", (req, res) => {
  const task = tasks.find((t) => t.id === Number(req.params.id));
  if (!task) return res.status(404).json({ error: "Task not found" });
  res.json(task);
});

app.post("/tasks", (req, res) => {
  const { title } = req.body;
  if (!title || typeof title !== "string") {
    return res.status(400).json({ error: "'title' is required" });
  }
  const newTask = { id: nextId++, title, done: false };
  tasks.push(newTask);
  res.status(201).json(newTask);
});

app.put("/tasks/:id", (req, res) => {
  const task = tasks.find((t) => t.id === Number(req.params.id));
  if (!task) return res.status(404).json({ error: "Task not found" });
  if (typeof req.body.title === "string") task.title = req.body.title;
  if (typeof req.body.done === "boolean") task.done = req.body.done;
  res.json(task);
});

app.delete("/tasks/:id", (req, res) => {
  const index = tasks.findIndex((t) => t.id === Number(req.params.id));
  if (index === -1) return res.status(404).json({ error: "Task not found" });
  const [deleted] = tasks.splice(index, 1);
  res.json(deleted);
});

// Runs for any URL/method that didn't match a route above.
app.use((req, res) => {
  res.status(404).json({ error: `No route for ${req.method} ${req.originalUrl}` });
});

const PORT = 3001;
app.listen(PORT, () => {
  console.log(`Tasks API (Express) listening on http://localhost:${PORT}`);
});
